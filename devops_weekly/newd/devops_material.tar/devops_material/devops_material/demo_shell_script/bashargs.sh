#!/bin/bash

osname=$1
echo $osname
echo $(uname -a)


# Anoop

echo $(head -1 /etc/os-release)
