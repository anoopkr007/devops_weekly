#!/bin/bash

ssh ec2-54-169-144-145.ap-southeast-1.compute.amazonaws.com

#ls > /tmp/list_files.txt
#tar -czf /tmp/list_files.tar.gz /tmp/list_files.txt

