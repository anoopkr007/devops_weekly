#!/bin/bash

echo "Enter a value between 1 to 5"
read case;

case $case in
1) echo "you have entered 1";;
2) echo "you have entered 2";;
3) echo "you have entered 3";;
4) echo "you have entered 4";;
5) echo "you have entered 5";;
esac
