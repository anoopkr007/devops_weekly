#!/bin/bash

for (( i=1; i <= 3; i++ ))
do
    echo "Your random number $i: $RANDOM"
done
