#!/bin/bash
set -x
printfunction () {

	echo Hello $1
	return 0
	}

printfunction Hello

printfunction "Big Data!"
