#!/bin/bash

#echo "Hi, please provide your name: \c"
echo "Hi, please provide your name:"
read name
echo "Hello $name !"
